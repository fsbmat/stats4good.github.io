time<- proc.time() 
beta2 = seq(-5, 5, 0.25);     n1 = length(beta2);
lambdac = seq(0.5, 5, 0.01);   n2 = length(lambdac);

N = 300
n = 50;
nb1 = 5; nb0 = n-nb1; # covariavel binaria (quantidade de 1's e 0's) 
# Gerando a 1a coavariavel

bet1 = -2
mu<-0;
sigma<-1;
output = array(0,c((n1*n2),4));
colnames(output) <- c("%VM", 
                      "%Cens",
                      "beta2",
                      "lambdac");
set.seed(123456789);
x1 = c(rep(1,nb1),rep(0,nb0));
T<-matrix(0,nrow=n, ncol=N);      
C<-matrix(0,nrow=n, ncol=N);
propcens <- array(0,c(N,1));

linha=1;
 for(j1 in 1:n1)
  {
    for(j2 in 1:n2)
    {
        contador = 0;
         for(t in 1:N)
          { 
          x2 = rnorm(n,mu,sigma);
          bet2 = beta2[j1];
          lambdc = lambdac[j2];
          
          preditor <- 0+(x1*bet1)+(x2*bet2)
          lambdat <- exp(preditor)
          C[,t]<-rexp(n,lambdc)
          T[,t]<-rexp(n,lambdat)
          evento <- as.numeric(T[,t]<=C[,t])                   
          propcens[t] <- 1-mean(evento)                         
          contador = contador+(sum(evento[(x1==1)]==0)==nb1)   
          }
          output[linha,1] = contador/N;                               
          output[linha,2] = sum(propcens)/N;
          output[linha,3] = beta2[j1];  
          output[linha,4] = lambdac[j2];            
          linha = linha+1;
          cat(round(100*linha/(n1*n2),2),"% \r")
          }
        }
  proc.time()-time


# Salvando o workspace...
#save.image("Simual��o_exp.RData")

#load("Simula��o_exp.RData")

id1 = (output[,1]==0.75) # 100% Verossimilhanca monotona
id2 = (output[,2]>0.70 & output[,2]<0.75) # % censura
sum(id1)
sum(id2)
output[id1==1,]
output[which(id1==1 & id2==1),]

########################################################################################
########################################################################################
########################################################################################

rm(list = ls(all=TRUE)); # Limpando workspace: apaga o que foi gerado anteriormente.

require(coxphf)
require(xtable)

set.seed(123456789);
N = 1000; # Numero de replicacoes
mu = 0; 
sig2 = 1; 

# configura��o nos diferentes cen�rios

# Cen�rio de 95% de VM
bet1= -2; bet2= -0.50 ; lam.c = 8.12;

# Cen�rio de 75% de VM
#bet1= -2.0; bet2= -0.75; lam.c =2.99

# Cen�rio de 50% de VM
#bet1= -2; bet2= -3; lam.c =8.22 

# Cen�rio de 25% de VM
#bet1= -2; bet2=  -6.50; lam.c = 22.85;

#
nb1 = 5; # covariavel binaria (quantidade de 1's)
s.size = c(50,100,200,300,400,600,800,1000)
ns = length(s.size)
#
tabela = array(0,c(ns,13)); tabela[,1] = s.size;
colnames(tabela) = c("n","% Cens","% VM","VR.b1","VR.b2","MSE.b1","MSE.b2","EP.b1","EP.b2","Cob.b1.wa","Cob.b2.wa","Cob.b1.pl","Cob.b2.pl")
#
for(k in 1:ns)
{  
  n = s.size[k]; # Tamanho amostral
  nb0 = n-nb1; # covariavel binaria (quantidade de 0's)  
  x1 = c(rep(1,nb1),rep(0,nb0))
  #
  T<-matrix(0,nrow=n, ncol=N);      
  C<-matrix(0,nrow=n, ncol=N);
  propcens = array(0,c(N,1));
  bet1.hat = array(0,c(N,1)); bet2.hat = array(0,c(N,1));
  bet1.ep = array(0,c(N,1)); bet2.ep = array(0,c(N,1));
  cob.bet1.wa = array(0,c(N,1)); cob.bet2.wa = array(0,c(N,1));
  cob.bet1.pl = array(0,c(N,1)); cob.bet2.pl = array(0,c(N,1));
  
  # Limites dos ICs
  ic.wa<-matrix(0, nrow = N, ncol = 4)
  ic.pl<-matrix(0, nrow = N, ncol = 4)
  MSE <- matrix(0, nrow = N, ncol = 2)
  
  contador=0;
  for(t in 1:N)
  {
    x2 = rnorm(n,mu,sqrt(sig2)); # Gerando 2a covariavel.
    preditor = 0+(bet1)*x1+(bet2)*x2 # Preditor linear
    lambdat = exp(preditor)
    C[,t] <- rexp(n, lam.c)          # Gerando os tempos de censura
    T[,t] <- rexp(n, lambdat) 
    evento = as.numeric(T[,t]<=C[,t])
    tempo = pmin(T[,t],C[,t])
    dados = data.frame(cbind(x1,x2,evento,tempo))
    
    # modelos de regress�o
    cox.wa = coxphf(Surv(tempo,evento)~x1+x2, pl = FALSE, data = dados, firth = TRUE)
    cox.pl = coxphf(Surv(tempo,evento)~x1+x2, pl = TRUE,  data = dados, firth = TRUE)
    
    # Estimativas
    bet1.hat[t] = cox.wa$coef[1]; bet2.hat[t] = cox.wa$coef[2]
    bet1.ep[t] = sqrt(diag(cox.wa$var))[1]; bet2.ep[t] = sqrt(diag(cox.wa$var))[2]
    
    # Cobertura usando wald
    cob.bet1.wa[t] = as.numeric(log(cox.wa$ci.lower[1])<=bet1 & log(cox.wa$ci.upper[1])>=bet1)
    cob.bet2.wa[t] = as.numeric(log(cox.wa$ci.lower[2])<=bet2 & log(cox.wa$ci.upper[2])>=bet2)
    
    # Cobertura usando vpl
    cob.bet1.pl[t] = as.numeric(log(cox.pl$ci.lower[1])<=bet1 & log(cox.pl$ci.upper[1])>=bet1)
    cob.bet2.pl[t] = as.numeric(log(cox.pl$ci.lower[2])<=bet2 & log(cox.pl$ci.upper[2])>=bet2)
    
    # ic.wa 
    ic.wa[t,1]=log(cox.wa$ci.lower[1]); ic.wa[t,2]=log(cox.wa$ci.upper[1]);
    ic.wa[t,3]=log(cox.wa$ci.lower[2]); ic.wa[t,4]=log(cox.wa$ci.upper[2]);
    
    # ic.pl
    ic.pl[t,1]=log(cox.pl$ci.lower[1]); ic.pl[t,2]=log(cox.pl$ci.upper[1]);
    ic.pl[t,3]=log(cox.pl$ci.lower[2]); ic.pl[t,4]=log(cox.pl$ci.upper[2]);
    
    # Quadrado m�dio do erro
    MSE[t,1] = (bet1-cox.wa$coef[1])^2;
    MSE[t,2] = (bet2-cox.wa$coef[2])^2;
    
    #
    propcens[t] = 1-mean(evento);
    contador = contador+(sum(evento[x1==1]==0)==nb1);
  }
  tabela[k,2] = 100*mean(propcens) # media prop.censuras nas N replicacoes.
  tabela[k,3] = 100*contador/N; # proporcao VM.
  tabela[k,4] = 100*(mean(bet1.hat)-bet1)/abs(bet1) # Vicio Relativo beta1 
  tabela[k,5] = 100*(mean(bet2.hat)-bet2)/abs(bet2) # Vicio Relativo beta2
  tabela[k,6] = mean(MSE[,1]) 
  tabela[k,7] = mean(MSE[,2]) 
  tabela[k,8] = mean(bet1.ep) # Erro padrao medio beta1
  tabela[k,9] = mean(bet2.ep) # Erro padrao medio beta2
  
  # Cobertura IC
  aux = na.omit(cob.bet1.wa); 
  tabela[k,10] = 100*sum(aux)/length(aux)
  aux = na.omit(cob.bet2.wa); 
  tabela[k,11] = 100*sum(aux)/length(aux)
  aux = na.omit(cob.bet1.pl); 
  tabela[k,12] = 100*sum(aux)/length(aux)
  aux = na.omit(cob.bet2.pl); 
  tabela[k,13] = 100*sum(aux)/length(aux)
  
  beta1=bet1.hat;
  beta2=bet2.hat;
  
  # Boxplots e Histogramas
  
  win.graph()
  par(mfrow=c(2,2))
  boxplot(beta1, xlab="beta1",col = "blue"); 
  legend("topleft",legend=c("n=",s.size[k]),xpd = TRUE,horiz=TRUE, cex=0.8)
  abline(h=bet1,v=0,col="red",lwd=2)
  boxplot(beta2, xlab="beta2", col = "blue"); 
  abline(h=bet2,v=0,col="red",lwd=2)
  hist(beta1, xlab = "beta1", freq = FALSE, ylim = c(0, 1.0));
  abline(v=bet1, col="red", lwd=2)
  curve(dnorm(x, mean = mean(bet1.hat), sd = sd(bet1.hat)), add = TRUE, lwd=2,col="blue");
  hist(beta2, xlab = "beta2", freq = FALSE);
  abline(v=bet2, col="red", lwd=2)                           # assume-se que h==0
  curve(dnorm(x, mean = mean(bet2.hat), sd = sd(bet2.hat)), add = TRUE,lwd=2, col="blue");
  
  # Gr�fico dos ICs
  #Wald
  win.graph()  
  par(mfrow=c(1,2))
  
  # ordena os estimativas
  or.b1<-order(beta1) 
  or.b2<-order(beta2)
  ic.wa_or = ic.wa[or.b1,]
  ic.pl_or = ic.pl[or.b1,]
  
  # remove os na's
  novo_ic.wa = na.omit(ic.wa_or)   
  novo_ic.pl = na.omit(ic.pl_or)
  beta1_ord = beta1[or.b1][1:length(novo_ic.pl[,2])] 
  beta2_ord = beta2[or.b2][1:length(novo_ic.pl[,2])]
  plot(x=c(-10,10),y=c(0,length(novo_ic.wa[,2])), type="n")
  abline(v=bet1,lty=2)
  legend("topleft",legend=c("n=",s.size[k]),xpd = TRUE,horiz=TRUE, cex=0.8)
  
  for(i in 1:length(novo_ic.wa[,2]))
  {
    if(novo_ic.wa[i,1]>bet1 | novo_ic.wa[i,2]<bet1){
      segments(x0=novo_ic.wa[i,1],y0=i,x1=novo_ic.wa[i,2],y1=i,col="red")
      points(x=beta1_ord[i], y=i, pch=19, col="red")} 
    else {
      segments(x0=novo_ic.wa[i,1],y0=i,x1=novo_ic.wa[i,2],y1=i)
      points(x=beta1_ord[i], y=i, pch=19)
    }
  }
  
  # vpl
  plot(x=c(-10,10),y=c(0,length(novo_ic.pl[,2])), type="n")
  abline(v=bet1,lty=2)
  
  for(l in 1:length(novo_ic.pl[,2]))
  {
    if(novo_ic.pl[l,1]>bet1 | novo_ic.pl[l,2]<bet1){
      segments(x0=novo_ic.pl[l,1], y0=l, x1=novo_ic.pl[l,2], y1=l, col="red")
      points(x=beta1_ord[l], y=l, pch=19, col="red")} 
    else {
      segments(x0=novo_ic.pl[l,1],y0=l,x1=novo_ic.pl[l,2], y1=l)
      points(x=beta1_ord[l], y=l, pch=19)
    }
  }
  
  cat(round(100*k/ns,2),"% \r")
}

# Salvando o workspace...
save.image("Sim1_vm98.RData")

round(tabela,2)
xtable(tabela)
