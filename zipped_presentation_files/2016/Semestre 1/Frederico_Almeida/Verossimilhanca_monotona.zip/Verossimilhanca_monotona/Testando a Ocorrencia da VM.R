

######################################################
#  Testando a Ocorrencia da Verossimilhan�a Mon�tona #
######################################################
require(coxphf)
require(survival)
n=50;
nb1=5
nb0=n-nb1
x2=rnorm(n)
x1=c(rep(1,nb1),rep(0,nb0))
t=rexp(n,2)
c=rexp(n,5)
tempo=pmin(t,c)
evento=as.numeric(t<=c)
#
#x1[evento==1]=evento[x1==1]=0;
#
evento<-1*(x1==0) # quando o evento n�o ocorre no n�vel x1=1
#
evento<-1*(x1==1) # quando o evento n�o ocorre no nivel x1=0 
table(x1,evento)

# Quebrando a VM
#x1[10:15]=evento[10:15]=0;
x1[10:15]=evento[10:15]=1;

cbind(x1,evento)

st.cox=coxph(Surv(tempo,evento)~x1+x2, method="breslow")
summary(st.cox)


##############################################################
#       Corre��o de Firth: reduz o vi�s da O(1)              #                
##############################################################


dados=data.frame(cbind(x1, x2, tempo, evento))
cox.pl = coxphf(Surv(tempo,evento)~x1+x2, pl = TRUE,  data = dados, firth = TRUE);
summary(cox.pl)







