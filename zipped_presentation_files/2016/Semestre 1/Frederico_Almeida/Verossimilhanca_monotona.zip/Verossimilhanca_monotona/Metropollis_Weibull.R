##METROPOLLIS##

rm(list=ls())
set.seed(123456789)
require(xtable)
require(flexsurv)
require(coda)

# cenário de 95% de VM 
#bet1 = -2; bet2 = -1.08; lam.c = 6.3; p.forma = 1.5;

# cen?rio de 75% de VM
#bet1 = -2; bet2 = -0.74; lam.c = 2.1; p.forma = 1.5;

# cen?rio sem VM
bet1 = -2; bet2 = -0.05; lam.c = 0.1; p.forma = 1.5;

sigma2 = 1;

alfa.real = p.forma;

##Burn-in
Npost=6000                                  # Amostra aposterior
burnin=1000                                 # Periodo de Burnin
lag=1                                         
Nint=burnin+lag*Npost                       # Número de interações

#sbeta = NULL;
#sbeta =array(0,c(Nint,2))
#colnames(sbeta) = c("sbeta1", "sbeta2", "alfa")
beta = array(0,c(Nint,2))
alfa = array(0,c(Nint,1))

N=1000;

# Especifica??es a priori
m1 = 0;
v1 = 1000;
m2 = 0;
v2 = 1000;
#

# Chutes para alfa
a = 0.001;   # shape
b = 0.001;   # rate

s.size = c(800,1000) #c(50,100,200,300,400,600,800,1000)
ns = length(s.size)

w1 =c(0.09,0.08) #c(1,1,1,1,1,0.9,0.9,0.9)
w2 =c(0.01,0.009)  #c(0.1,0.08,0.1,0.1,0.1,0.1,0.2,0.2)
w3 =c(0.009,0.009)  #c(0.1,0.09,0.2,0.2,0.1,0.1,0.1,0.1)

#
tabela = array(0,c(ns,18)); tabela[,1] = s.size;
colnames(tabela) = c("n","% Cens","% VM","VR.b1","VR.b2","VR.alfa","EQM.b1","EQM.b2","EQM.alfa","EP.b1","EP.b2","EP.alfa","Cob.b1","Cob.b2","Cob.alfa", "Tx.Rej.b1", "Tx.Rej.b2", "TR.alfa")

for(k in 1:ns)
{ 
  n = s.size[k]; # Tamanho amostral
  # Gerando a 1a coavariavel
  nb1 = 5;
  nb0 = n-nb1; # covariavel binaria (quantidade de 0's)  
  x1 = c(rep(1,nb1),rep(0,nb0))
  
  # Coberturas
  cob.b1=array(0,c(N,1));
  cob.b2=array(0,c(N,1));
  cob.alfa=array(0,c(N,1)); 
  
  propcens=array(0,c(N,1));
  EQM = array(0,c(N,3));
  
  med.sbeta1=array(0,c(N,1));
  med.sbeta2=array(0,c(N,1));
  med.salfa=array(0,c(N,1));
  
  ic.b1g = array(0,c(N,2));
  ic.b2g = array(0,c(N,2));
  ic.alfag = array(0,c(N,2));
    
  # Cadeias
  nburnin=Nint-burnin;
  cadeia.b1=matrix(0, nrow=nburnin, ncol=N);
  cadeia.b2=matrix(0, nrow=nburnin, ncol=N);
  cadeia.alfa=matrix(0, nrow=nburnin, ncol=N);
  
  contador = 0;
  for (j in 1:N)
  {     
  x2<-rnorm(n, 0, sqrt(sigma2))
  preditor = bet1*x1+bet2*x2
  lambdat = exp(preditor)
  X = cbind(x1,x2)
  
  # Gerando os tempos de sobreviv?ncia e censuras
  t=rweibullPH(n, shape = p.forma, scale = lambdat);
  c=rexp(n, lam.c);
  tempo=pmin(t,c);
  delta = as.numeric(t<=c);    
  d = sum(delta);
  
  
  # chutes inicias
  beta[1,1]=0;
  beta[1,2]=0;
  alfa[1] = 1;
  
  Taxab1=0; Taxab2=0; Taxa.alfa=0;  
  
  for (i in 2:Nint){
    
    beta_ast = cbind(beta[i-1,1],beta[i-1,2])
    
    # Gerando candidatos
    bet1_c=rnorm(1,mean=beta[i-1,1],sd=sqrt(w1))                    # Beta candidato
    bet2_c=rnorm(1,mean=beta[i-1,2],sd=sqrt(w2))                    # Beta candidato
    
    alfa_c = rnorm(1, mean=alfa[i-1], sd=sqrt(w3))
    
    if(alfa_c>0){log_pcand.alfa=(d+a-1)*log(alfa_c)+alfa_c*(delta%*%log(tempo)-b)-
       tempo^(alfa_c)%*%exp(X%*%t(beta_ast))
      
       log_p.alfa=(d+a-1)*log(alfa[i-1])+alfa[i-1]*(delta%*%log(tempo)-b)-
       tempo^(alfa[i-1])%*%exp(X%*%t(beta_ast))
                 
       Q.alfa=log_pcand.alfa-log_p.alfa
                 
       U.alfa =runif(1)
       alfa.seg=min(0,Q.alfa)
       if(U.alfa < exp(alfa.seg)){alfa[i]=alfa_c; Taxa.alfa=Taxa.alfa+1}
       else{alfa[i]=alfa[i-1]}
       }
    
       if(alfa_c<=0){
      alfa[i]=alfa[i-1]}
    
        # posterior real
    post.real.b1 = (1/(-2*v1))*(beta[i-1,1]^2-2*beta[i-1,1]*m1)-
      tempo^(alfa[i-1])%*%exp(X%*%t(beta_ast))+beta[i-1,1]*delta%*%x1
    
    # posterior candidata
    post.cand.b1 = (1/(-2*v1))*(bet1_c^2-2*bet1_c*m1)-
      tempo^(alfa[i-1])%*%exp(bet1_c*x1+beta[i-1,2]*x2)+bet1_c*delta%*%x1
    
    Q1=post.cand.b1-post.real.b1
    
    # gerando a uniforme
    U1=runif(1)
    alfa1=min(0,Q1)
    if (U1 < exp(alfa1)) {beta[i,1]=bet1_c; Taxab1=Taxab1+1}    
    else {beta[i,1]=beta[i-1,1]}    
    
    # posterior real
    post.real.b2 = (1/(-2*v2))*(beta[i-1,2]^2-2*beta[i-1,2]*m2)-
      tempo^(alfa[i-1])%*%exp(X%*%t(beta_ast))+beta[i-1,2]*delta%*%x2
    
    # posterior candidata
    post.cand.b2 = (1/(-2*v2))*(bet2_c^2-2*bet2_c*m2)-
      tempo^(alfa[i-1])%*%exp(beta[i-1,1]*x1+bet2_c*x2)+bet2_c*delta%*%x2
    
    Q2=post.cand.b2-post.real.b2
    
    # gerando a uniforme
    U2=runif(1)
    alfa2=min(0,Q2)
    if (U2 < exp(alfa2)) {beta[i,2]=bet2_c; Taxab2=Taxab2+1}    
    else {beta[i,2]=beta[i-1,2]}    
    
    sbeta=cbind(beta[,1],beta[,2],alfa)
   }
  
  # store
   sbeta1=sbeta[-(1:burnin),1];
   sbeta2=sbeta[-(1:burnin),2];
   salfa =sbeta[-(1:burnin),3];
   
   # Guarda as 1000 cadeias de cada parametro
  
   cadeia.b1[,j]=sbeta1;
   cadeia.b2[,j]=sbeta2;
   cadeia.alfa[,j]=salfa;
  
  # Guarda as m?dias das 1000 cadeias de cada beta 
   med.sbeta1[j]=mean(sbeta1)
   med.sbeta2[j]=mean(sbeta2)
   med.salfa[j] =mean(salfa)  
  
   # HPD
   sbeta=sbeta[(burnin+1):Nint,]
   cadeias=as.mcmc(sbeta)
   HPD=HPDinterval(cadeias, prob = 0.95)
   
   # Guarda limites dos int. de cerdibilidade para beta1 para consruir o gr�fico
   ic.b1g[j,1]=HPD[1,1];
   ic.b1g[j,2]=HPD[1,2];
   
   # Guarda os limites do I.cred de beta2 para consruir o gr�fico
   ic.b2g[j,1]=HPD[2,1];
   ic.b2g[j,2]=HPD[2,2];
   
   # Guarda os limites do IC de alfa para consruir o gr�fico
   ic.alfag[j,1]=HPD[3,1];
   ic.alfag[j,2]=HPD[3,2];
   
   # Coberturas
   cob.b1[j] = as.numeric(ic.b1g[j,1]<=bet1 & bet1<=ic.b1g[j,2]);
   cob.b2[j] = as.numeric(ic.b2g[j,1]<=bet2 & bet2<=ic.b2g[j,2]);
   cob.alfa[j] = as.numeric(ic.alfag[j,1]<=alfa.real & alfa.real<=ic.alfag[j,2]);
   
    # % de VM e Censuras
    propcens[j] = 1-mean(delta);
    contador = contador+(sum(delta[x1==1]==0)==nb1);
    
    # Erro quadrático médio
    EQM[j,1] = (med.sbeta1[j]-bet1)^2;
    EQM[j,2] = (med.sbeta2[j]-bet2)^2;
    EQM[j,3] = (med.salfa[j]-alfa.real)^2;
  }
  
  tabela[k,2] = 100*mean(propcens)                             # media prop.censuras nas N replicacoes.
  tabela[k,3] = 100*contador/N;                                # proporcao VM.
  tabela[k,4] = 100*(mean(med.sbeta1)-bet1)/abs(bet1)          # Vicio Relativo beta1 
  tabela[k,5] = 100*(mean(med.sbeta2)-bet2)/abs(bet2)          # Vicio Relativo beta2
  tabela[k,6] = 100*(mean(med.salfa)-alfa.real)/abs(alfa.real) # Vicio Relativo beta2
  tabela[k,7] = 100*mean(EQM[,1]);                                 # Erro quadr?tico médio
  tabela[k,8] = 100*mean(EQM[,2]);
  tabela[k,9] = 100*mean(EQM[,3]);
  tabela[k,10] = sd(med.sbeta1)                                 # Erro padrao medio beta1
  tabela[k,11] = sd(med.sbeta2)                                 # Erro padrao medio beta2
  tabela[k,12] = sd(med.salfa)                                  # Erro padrao medio alfa
  tabela[k,13] = 100*sum(cob.b1)/N;                             # Taxas de Coberturas
  tabela[k,14] = 100*sum(cob.b2)/N;  
  tabela[k,15] = 100*sum(cob.alfa)/N;
  tabela[k,16] = 100*Taxab1/Nint;
  tabela[k,17] = 100*Taxab2/Nint;                           # Taxas de rejei??o
  tabela[k,18] = 100*Taxa.alfa/Nint;
  
  # Gr?ficos
  x11()
  par(mfrow=c(2,3));
  
  # beta1
  hist(med.sbeta1, freq=FALSE, main = "beta1");
  abline(h=0, v=bet1, col="red", lwd=2)
  legend("topleft",legend=c("n=",s.size[k]),xpd = TRUE,horiz=TRUE, cex=0.8)
  curve(dnorm(x, mean = mean(med.sbeta1), sd = sd(med.sbeta1)), add = TRUE, lwd = 2, col = "blue");
  
  # beta2
  hist(med.sbeta2, freq=FALSE, main = "beta2");
  abline(h=0, v=bet2, col="red", lwd=2)
  curve(dnorm(x, mean = mean(med.sbeta2), sd = sd(med.sbeta2)), add = TRUE, lwd = 2, col = "blue");
  
  # alfa
  hist(med.salfa, freq=FALSE, main = "alfa");
  abline(h=0,v=alfa.real,col="red",lwd=2)
  curve(dnorm(x, mean = mean(med.salfa), sd = sd(med.salfa)), add = TRUE, lwd = 2, col = "blue");
  
  #Boxpolts
  boxplot(med.sbeta1, xlab="beta1",col = "blue"); 
  abline(h=bet1, v=0, col="red", lwd=2)
  boxplot(med.sbeta2, xlab="beta2", col = "blue"); 
  abline(h=bet2, v=0, col="red", lwd=2)
  boxplot(med.salfa, xlab="beta2", col = "blue"); 
  abline(h=alfa.real, v=0, col="red", lwd=2)
  
  # Gr�ficos
  x11()
  par(mfrow=c(1,3))
  
  # beta1
  #plot(med.sbeta1,ylab="beta1",xlab="N�mero de intera��es das m�dias",type="l",cex.axis=1.5,cex.lab=1.5)
  #legend("topleft", legend=c("n=",s.size[k]), xpd = TRUE, horiz = TRUE, cex=0.8)
  #abline(bet1, 0, col="red", lwd=2);
  
  # beta2
  #plot(med.sbeta2,ylab="beta2",xlab="N�mero de intera��es das m�dias",type="l",cex.axis=1.5,cex.lab=1.5)
  #abline(bet2, 0, col="red", lwd=2)
  
  # alfa
  #plot(med.salfa,ylab="alfa",xlab="N�mero de intera��es das m�dias",type="l",cex.axis=1.5,cex.lab=1.5)
  #abline(alfa.real, 0, col="red", lwd=2);
  
  # Intervalos de Credibilidade
  # ordena os estimativas
  or.b1<-order(med.sbeta1) 
  or.b2<-order(med.sbeta2)
  or.alfa<-order(med.salfa)
  
    
  ic.b1_or = ic.b1g[or.b1,]
  ic.b2_or = ic.b2g[or.b2,]
  ic.alfa_or = ic.alfag[or.alfa,]
  
  beta1_ord = med.sbeta1[or.b1][1:N] 
  beta2_ord = med.sbeta2[or.b2][1:N]
  alfa_ord = med.salfa[or.alfa][1:N]
  
  # Sem NAs length(ic.b1g[,1])==N
  
  # beta1
  plot(y=c(-10,10), x=c(0,N), type="n", xlab="N�mero de Monte Carlos", ylab="Intervalos de credibilidade beta1",cex.axis=1.5,cex.lab=1.5)
  legend("topleft", legend=c("n=",s.size[k]), xpd = TRUE, horiz = TRUE, cex=0.8)
  abline(h=bet1,lty=2, col="darkblue")
  
  for(i in 1:N)
  {
    if(ic.b1_or[i,1]>bet1 | bet1>ic.b1_or[i,2]){
      segments(y0=ic.b1_or[i,1],x0=i, y1=ic.b1_or[i,2], x1=i,col="red")
      points(y=beta1_ord[i], x=i, pch=19, col="black")} 
    else {
      segments(y0=ic.b1_or[i,1],x0=i,y1=ic.b1_or[i,2],x1=i)
      points(y=beta1_ord[i], x=i, pch=19)
    }
  }
  
  # beta2
  plot(y=c(-3,3),x=c(0,N), type="n",xlab="N�mero de Monte Carlos",ylab="Intervalos de credibilidade beta2",cex.axis=1.5,cex.lab=1.5)
  abline(h=bet2,lty=2, col="darkblue")
  
  for(i in 1:N)
  {
    if(ic.b2_or[i,1]>bet2 | ic.b2_or[i,2]<bet2){
      segments(y0=ic.b2_or[i,1], x0=i, y1=ic.b2_or[i,2], x1=i, col="red")
      points(y=beta2_ord[i], x=i, pch=19, col="black")} 
    else {
      segments(y0=ic.b2_or[i,1], x0=i,y1=ic.b2_or[i,2], x1=i)
      points(y=beta2_ord[i], x=i, pch=19)
    }
  }
  
  
  # Alfa
  plot(y=c(-3,3), x=c(0,N), type="n",xlab="N�mero de Monte Carlos", ylab="Intervalos de credibilidade alfa",cex.axis=1.5,cex.lab=1.5)
  abline(h=alfa.real,lty=2, col="darkblue")
  
  for(i in 1:N)
  {
    if(ic.alfa_or[i,1]>alfa.real | ic.alfa_or[i,2]<alfa.real){
      segments(y0=ic.alfa_or[i,1],x0=i, y1=ic.alfa_or[i,2],x1=i,col="red")
      points(y=alfa_ord[i], x=i, pch=19, col="black")} 
    else {
      segments(y0=ic.alfa_or[i,1], x0=i, y1=ic.alfa_or[i,2], x1=i)
      points(y=alfa_ord[i], x=i, pch=19)
    }
  }
cat(100*k/ns, "% \r")
}

round(tabela,2)
xtable(tabela)


